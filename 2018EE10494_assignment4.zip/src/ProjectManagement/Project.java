package ProjectManagement;

public class Project {
    public String name;
    public int priority;
    public int budget;

    Project(String name, int priority, int budget) {
        this.name = name;
        this.priority = priority;
        this.budget = budget;
    }
}
