package Util;

public interface NodeInterface<T> {

    T getValue();

}
